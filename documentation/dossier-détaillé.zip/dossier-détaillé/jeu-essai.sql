-- JEUX D'ESSAIS (à compléter)

-- Table Coordonnées

INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (1,'21, rue PHP',NULL,14000,'Caen',"0611528496","bin.damien@afpa.fr");
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (2,'15, rue des framework',NULL,14800,'Deauville','0641489575','bray.vincent@afpa.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (3,'7, rue de Girard',NULL,14123,'IFS','0614859753','gauthier.remy@afpa.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (4,'698, boulevard Grégoire Thomas',NULL,14200,'Herouville-Saint-Clair','0612596574','albert.emile@afpa.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (5,'16, rue de Pruvost',NULL,14120,'Mondeville','0658748562','traore.gerard@afpa.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (6,'60, avenue Duval',NULL,14200,'Herouville-Saint-Clair','0654859742','labbe.joseph@afpa.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (7,'6, boulevard de Benoit',NULL,14000,'Caen','0659863215','huet.aurelie@afpa.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (8,'43, chemin Caron',NULL,14000,'Caen','0694758196','antoine.philippe@afpa.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (9,'677, avenue Daniel Moulin',NULL,14123,'IFS','0623985475','lauranne.susanne@afpa.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (10,'55, place William Teixeira',NULL,14123,'IFS','0617485965','mary.alex@afpa.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (11,'39, avenue du Maréchal Juin',NULL,50000,'St-Lô',0238329985,'MartinMarguerite@sfr.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (12,'49, avenue du Maréchal du Maréchal de Lattre de Tasigny',NULL,14000,'Caen',0239220984,'GarciaThérèse@flute.jsp');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (13,'59, rue des Lacs',NULL, 14200,'Hérouville-Saint-Clair',0679631569,'BruceRiquier@rhyta.com');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (14,'50 rue des Lacs',NULL,14200,'Hérouville-Saint-Clair',0636987525,'XavierDenis@armyspy.com');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (15,'5, Chemin des Bateliers',NULL, 61000, 'Alençon',0632154785, 'PatriciaCharlebois@dayrep.com');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (16, '29, rue Ernest Renan', NULL, 50100 ,'Cherbourg',0687412569,'MainvilleAvent@orange.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (17,'94, Chemin des Bateliers',NULL, 61000, 'Alençon',0658741256, 'RosemarieBordeaux@free.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (18, '16 avenue Marechal Juin',NULL, 50000, 'Saint-Lô',0625897412, 'ElodieLamothe@sfr.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (19, '66, Chemin Du Lavarin Sud',NULL, 14000, 'Caen',0612369854,'SydneyCourse@gmail.com');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (20, '50, Chemin Des Bateliers' ,NULL,14000 'Caen',0698745213,'SamsonThomas@gmail.com' );
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (21, '305, Avenue du Javscript', 'étage 3, porte 8 ',14000,'Caen',0641236952, 'WagnerRené@yahoo.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (22, '45, Boulevard du Chalumeau','Batiment3, porte 2',14400,'Bayeux',0698741236,'LefevreNath@yahoo.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (23,'79, rue Léon Dierx', NULL, 14100, 'Lisieux',0658741236,'GallerValérie@gmail.com');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (24,'46, allée du Pinceau',NULL,14260,'Bonnemaison',0666988744,'LerouxMargaret@red.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (25,'86, rue du cable','Etage 3, port 6', 14710, 'Colombière', 0633358742, BergerGrégoire@gmail.com);
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (26,'163, boulevard du Touriste',NULL,14800,'Deauville',0699887744,'BruneauHonoré@free.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (27,'63, boulevard du Maréchal Leclerc',NULL,'Caen',0613214598,'VasseurBenoit@orange.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (28,'192, allée de la Taule',NULL, 14840,'Démouville',0658741238,'PelletierRemy@yahoo.fr');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (29,'1, rue du Grand Tableau',NULL,14730,'Giberville',0687489632,'FabreAdélaide@gmail.com');
INSERT INTO `Coordonnees`(`IDCoordonnee`, `Adresse1`, `Adresse2`, `Code_Postale`, `Ville`, `Telephone`, `Mail`) VALUES (30,'41, avenue du pot Peinture', 'Batiment 2, étage 8, porte 5', 14100, 'Glos', 0614852369,'CharrierLouis@free.fr');


-- Table SessionExamen

INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (2,'2022-10-12');
INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (3,'2022-03-26');
INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (4,'2021-08-19');
INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (5,'2021-08-13');
INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (6,'2022-03-29');
INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (7,'2021-01-16');
INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (8,'2021-09-13');
INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (9,'2022-03-29');
INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (10,'2022-12-18');
INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (11,'2022-03-29');
INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (12,'2021-08-14');
INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (13,'2020-02-16');
INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (14,'2020-10-29');
INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (15,'2021-12-06');
INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (16,'2022-07-16');
INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (17,'2021-06-08');
INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (18,'2022-02-29');
INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (19,'2022-06-22');
INSERT INTO `SessionExamen`(`IDSessionExam`, `DateSessionExam`) VALUES (20,'2022-12-21');


-- Table Formateur LOL

INSERT INTO `Formateur`(`IDFormateur`, `Nom_du_formateur`, `Prenom_du_Formateur`, `IDCoordonnee`) VALUES (1,'BIN','Damien',1);
INSERT INTO `Formateur`(`IDFormateur`, `Nom_du_formateur`, `Prenom_du_Formateur`, `IDCoordonnee`) VALUES (2,'BRAY','Vincent',2);
INSERT INTO `Formateur`(`IDFormateur`, `Nom_du_formateur`, `Prenom_du_Formateur`, `IDCoordonnee`) VALUES (3,'GAUTHIER','Rémy',3);
INSERT INTO `Formateur`(`IDFormateur`, `Nom_du_formateur`, `Prenom_du_Formateur`, `IDCoordonnee`) VALUES (4,'ALBERT','Emile',4);
INSERT INTO `Formateur`(`IDFormateur`, `Nom_du_formateur`, `Prenom_du_Formateur`, `IDCoordonnee`) VALUES (5,'TRAORE','Gérard',5);
INSERT INTO `Formateur`(`IDFormateur`, `Nom_du_formateur`, `Prenom_du_Formateur`, `IDCoordonnee`) VALUES (6,'LABBE','Joseph',6);
INSERT INTO `Formateur`(`IDFormateur`, `Nom_du_formateur`, `Prenom_du_Formateur`, `IDCoordonnee`) VALUES (7,'HUET','Aurélie',7);
INSERT INTO `Formateur`(`IDFormateur`, `Nom_du_formateur`, `Prenom_du_Formateur`, `IDCoordonnee`) VALUES (8,'ANTOINE','Philippe',8);
INSERT INTO `Formateur`(`IDFormateur`, `Nom_du_formateur`, `Prenom_du_Formateur`, `IDCoordonnee`) VALUES (9,'LAROCHE','Susanne',9);
INSERT INTO `Formateur`(`IDFormateur`, `Nom_du_formateur`, `Prenom_du_Formateur`, `IDCoordonnee`) VALUES (10,'MARY','Alex',10);

-- Table Formation

INSERT INTO `Formation`(`IDFormation`, `Intitule_de_formation`, `IDFormateur`) VALUES (1,"Developpeur WEB",1);
INSERT INTO `Formation`(`IDFormation`, `Intitule_de_formation`, `IDFormateur`) VALUES (2,"Technicien Réseaux Informatique",2);
INSERT INTO `Formation`(`IDFormation`, `Intitule_de_formation`, `IDFormateur`) VALUES (3,"Chaudronnerie",3);
INSERT INTO `Formation`(`IDFormation`, `Intitule_de_formation`, `IDFormateur`) VALUES (4,"Carrossier Réparateur",4);
INSERT INTO `Formation`(`IDFormation`, `Intitule_de_formation`, `IDFormateur`) VALUES (5,"Peintre en Carrosserie",5);
INSERT INTO `Formation`(`IDFormation`, `Intitule_de_formation`, `IDFormateur`) VALUES (6,"Chauffeur-livreur",6);
INSERT INTO `Formation`(`IDFormation`, `Intitule_de_formation`, `IDFormateur`) VALUES (7,"Chef d'équipe gros œuvre",7);
INSERT INTO `Formation`(`IDFormation`, `Intitule_de_formation`, `IDFormateur`) VALUES (8,"Responsable d'établissement touristique",8);
INSERT INTO `Formation`(`IDFormation`, `Intitule_de_formation`, `IDFormateur`) VALUES (9,"Serveur en restauration",9);
INSERT INTO `Formation`(`IDFormation`, `Intitule_de_formation`, `IDFormateur`) VALUES (10,"Technicien froid et climatisation",10);


-- Table SessionFormation

INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (1,'2021-05-31','2022-02-18',2,1,1);
INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (2,'2022-01-05','2022-10-14',3,1,1);
INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (3,'2021-09-17','2022-03-28',4,2,2);
INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (4,'2020-12-01','2021-08-21',5,2,2);
INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (5,'2021-01-31','2021-08-15',6,3,3);
INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (6,'2021-08-16','2022-03-31',7,3,3);
INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (7,'2020-05-16','2021-01-18',8,4,4);
INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (8,'2021-01-25','2021-09-15',9,4,4);
INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (9,'2021-08-16','2022-03-31',10,5,5);
INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (10,'2022-04-15','2022-12-20',11,5,5);
INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (11,'2021-08-16','2022-03-31',12,6,6);
INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (12,'2021-02-16','2021-08-16',13,6,6);
INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (13,'2019-05-31','2020-02-18',14,7,7);
INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (14,'2020-02-31','2020-10-31',15,7,7);
INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (15,'2021-04-01','2021-12-05',16,8,8);
INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (16,'2021-12-15','2022-07-18',17,8,8);
INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (17,'2020-10-16','2021-06-10',18,9,9);
INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (18,'2021-06-15','2022-02-28',19,9,9);
INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (19,'2022-01-16','2022-06-24',20,10,10);
-- INSERT INTO `Session_Formation`(`IDSessionFormation`, `DateDebutFormation`, `DateFinFormation`, `IDSessionExam`, `IDFormateur`, `IDFormation`) VALUES (20,'2022-06-26','2022-12-23',1,10,10);

-- Table jure
INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (1,'Martin','Marguerite','true',1,1,11); 

INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (2,'Thérèse', 'Garcia','true',2,2,12); 

INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (3,'Riquier','Bruce','true','true'3,3,13); 


INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (4,'Denis','Xavier','true','false',4,4,14); 

INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (5,'Charlebois','Patricia','true','false',5,5,15); 

INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (6,'Mainville','Avent','false','true',6,6,16); 
  

INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (7,'Bordeaux','Rosemarie','false','true',7,7,17); 

INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (8,'Lamothe','Elodie','true','true',8,8,18); 

INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (9,'Course','Sydney','true','false',9,9,19); 

INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (10,'Samson','Thomas','true','false',10,10,20); 
-- Reprendre à partir d'ici.
INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (11,' Wagner','René','true','false',11,11,21); 

INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (12,'Lefevre','Nath','true','false',12,12,22); 

INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (13,'Galler','Valérie','false','true',13,13,23); 

INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (14,'Leroux','Margaret','true','true',14,14,24); 

INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (15,'Berger','Grégoire','false','false',15,15,25); 

INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (16,'Bruneau','Honoré','true','false',16,16,26); 

INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (17,'Benoit','Vasseur','true','false',17,17,27); 

INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (18,'Pelletier','Rémy','true','false',18,18,28); 

INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (19,'Fabre','Adélaide','true','false',19,19,29); 

INSERT INTO `Jure`(`IDJure`, `NomJures`, `PrenomJures`, `Visible_sur_Ceres`, `Visible_sur_Valce`, `IDHabilitation`, `IDEntreprise`, `IDCoordonnee`) 
VALUES (20,'Charrier','Louis','true','true',20,20,30); 


